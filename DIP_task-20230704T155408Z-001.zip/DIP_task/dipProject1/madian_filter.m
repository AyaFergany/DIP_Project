function varargout = madian_filter(varargin)
% MADIAN_FILTER MATLAB code for madian_filter.fig
%      MADIAN_FILTER, by itself, creates a new MADIAN_FILTER or raises the existing
%      singleton*.
%
%      H = MADIAN_FILTER returns the handle to a new MADIAN_FILTER or the handle to
%      the existing singleton*.
%
%      MADIAN_FILTER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MADIAN_FILTER.M with the given input arguments.
%
%      MADIAN_FILTER('Property','Value',...) creates a new MADIAN_FILTER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before madian_filter_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to madian_filter_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help madian_filter

% Last Modified by GUIDE v2.5 04-May-2022 18:23:27

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @madian_filter_OpeningFcn, ...
                   'gui_OutputFcn',  @madian_filter_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before madian_filter is made visible.
function madian_filter_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to madian_filter (see VARARGIN)

% Choose default command line output for madian_filter
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes madian_filter wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = madian_filter_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in selectImage.
function selectImage_Callback(hObject, eventdata, handles)
   [filename, pathname] = uigetfile({'*.jpg';'*.bmp';'*.png'},'File Selector');
    global image 
    image = strcat(pathname, filename);
    global originalImage
    originalImage = imread(image);
    originalImage=imnoise(originalImage,'salt & pepper',0.2);
    axes(handles.axes1);
    imshow(originalImage )

% --- Executes on button press in editImage.
function editImage_Callback(hObject, eventdata, handles)
 global originalImage
 x=im2double(originalImage);
 output=x;
 [r c]=size(x);
    for i=2:r-1
       for j=2:c-1
           mat=[x(i-1,j-1),x(i-1,j),x(i-1,j+1),x(i,j-1),x(i,j),x(i,j+1),x(i+1,j-1),x(i+1,j),x(i+1,j+1)];
           
           mat=sort(mat);
           output(i,j)=mat(5);
          
       end
    end 
    
 axes(handles.axes3);
 imshow(output)
     

 


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close;
open('sec.fig');
