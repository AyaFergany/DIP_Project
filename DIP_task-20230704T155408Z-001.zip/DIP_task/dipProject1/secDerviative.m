function varargout = secDerviative(varargin)
% SECDERVIATIVE MATLAB code for secDerviative.fig
%      SECDERVIATIVE, by itself, creates a new SECDERVIATIVE or raises the existing
%      singleton*.
%
%      H = SECDERVIATIVE returns the handle to a new SECDERVIATIVE or the handle to
%      the existing singleton*.
%
%      SECDERVIATIVE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SECDERVIATIVE.M with the given input arguments.
%
%      SECDERVIATIVE('Property','Value',...) creates a new SECDERVIATIVE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before secDerviative_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to secDerviative_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help secDerviative

% Last Modified by GUIDE v2.5 10-May-2022 15:30:49

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @secDerviative_OpeningFcn, ...
                   'gui_OutputFcn',  @secDerviative_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before secDerviative is made visible.
function secDerviative_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to secDerviative (see VARARGIN)

% Choose default command line output for secDerviative
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes secDerviative wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = secDerviative_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname] = uigetfile({'.jpg';'.*'},'File Selector');
 global image 
 image = strcat(pathname, filename);
global originalImage
originalImage = imread(image);
axes(handles.axes1);
imshow(originalImage )  
 



% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global originalImage;
grayImage = originalImage;
gray_image=double(grayImage);
[rows cols noMatrex]= size (gray_image);
%Sharp
mask=[0,-1,0;-1,5,-1;0,-1,0];


out=gray_image;
for i=2:rows-1
 for j=2:cols-1
     temp=mask.*gray_image(i-1:i+1,j-1:j+1);
     value=sum(temp(:));
     out(i,j)=value;
 end 
end 
axes(handles.axes2);
imshow(out);
